    
        <div class="footer">
            <div class="no-gutters">
                <div class="col-auto mx-auto">
                    <div class="row no-gutters justify-content-center">
                        <div class="col-auto">
                            <a href="home.php" class="btn btn-link-default active">
                                <i class="material-icons">home</i>
                            </a>
                        </div>
                        <div class="col-auto">
                            <a href="notification.php" class="btn btn-link-default">
                                <i class="material-icons">info</i>
                            </a>
                        </div>
                        <div class="col-auto">
                            <a href="total-book.php" class="btn btn-default shadow centerbutton">
                                <i class=" fa fa-stethoscope" style="font-size: 18px; font-weight: bold;"></i>
                            </a>
                        </div>
                        <div class="col-auto">
                            <a href="history.php" class="btn btn-link-default">
                                <i class="material-icons">history</i>
                            </a>
                        </div>
                        <div class="col-auto">
                            <a href="profile.php" class="btn btn-link-default">
                                <i class="material-icons">account_circle</i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>